//
// Created by Oliver Reeves on 07/12/2022.
//
#include "string"
#include "map"
#include "vector"
#include <iostream>
#include <chrono>
#include <fstream>
#include <utility>
#ifndef TASK_2_RSE_ALGORITHM_H
#define TASK_2_RSE_ALGORITHM_H

#endif //TASK_2_RSE_ALGORITHM_H
using namespace std;
class RSEWORST{
public:
    map<string, string> mapOfBricks;
    map<string, string> reversedmapOfBricks;
    std::pair<std::string,std::string> startValues;
    vector<string>  royalList;

    void loadData(string a);
    vector<string> RoyalAlgorithm(string currentBrick,string nextBrick,int option);


private:



};

void RSEWORST::loadData(std::string a) {
    std::fstream readfile(a);
    std::string line;
    std::getline(readfile,line);
    auto index = line.find(',');
    std::pair<std::string,std::string> sep;

    sep = std::make_pair(
            line.substr(0,index),
            line.substr(index+1)
    );
    mapOfBricks[sep.first]=sep.second;
    startValues={sep.first,sep.second};

    while (std::getline(readfile, line))
    {
        // Line contains string of length > 0 then save it in vector

        //std::string str;
        auto index = line.find(',');


        sep = std::make_pair(
                line.substr(0,index),
                line.substr(index+1)
        );
        mapOfBricks[sep.first]=sep.second;
    }
    //steady_clock::time_point loadFinishTime = steady_clock::now();

    //steady_clock::time_point algoStartTime = steady_clock::now();
    for(auto i:mapOfBricks){
        reversedmapOfBricks[i.second]=i.first;
    }
    royalList.reserve(mapOfBricks.size());
}

vector<string> RSEWORST::RoyalAlgorithm(string currentBrick,string nextBrick,int option) {

    //cout<<"current brick"<<currentBrick<<endl;
    //cout<<"next brick"<<nextBrick<<endl;
    //forward search x x+1-> x+1 x+2->x+2 x+3
    //case 0
    while(1==1){
        //if found
        if (mapOfBricks.find(nextBrick) != mapOfBricks.end()) {
            //cout << "linked brick is" << mapOfBricks.find(nextBrick)->first << " "
            //   << mapOfBricks.find(nextBrick)->second << endl;
            royalList.push_back(currentBrick);
            currentBrick = mapOfBricks.find(nextBrick)->first;
            nextBrick = mapOfBricks.find(nextBrick)->second;



        } else {
            //push brick that was linked to missing brick
            royalList.push_back(currentBrick);
            royalList.push_back(nextBrick);

            //now we reverse the order
            currentBrick=startValues.first;
            nextBrick=startValues.second;
            break;

        }

    }
    //case 2
    while(1==1){
        //backwards x x+1 -> x+5 x

        if (reversedmapOfBricks.find(nextBrick) != reversedmapOfBricks.end()) {
            // cout << "rev linked brick is" << reversedmapOfBricks.find(nextBrick)->first << " "
            //    << reversedmapOfBricks.find(nextBrick)->second << endl;
            if((currentBrick!=startValues.first and currentBrick!=startValues.second)or(currentBrick==startValues.first and nextBrick!=startValues.first and nextBrick!=startValues.second)){
                royalList.insert(royalList.begin(),nextBrick);}


            currentBrick = reversedmapOfBricks.find(nextBrick)->first;
            nextBrick = reversedmapOfBricks.find(nextBrick)->second;


        } else {
            //push brick that was linked to missing brick
            royalList.insert(royalList.begin(),nextBrick);
            return royalList;
        }


    }


}
