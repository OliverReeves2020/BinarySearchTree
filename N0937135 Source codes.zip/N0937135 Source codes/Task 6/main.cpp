#include <iostream>
#include <list>
#include <string>
#include <vector>
#include <fstream>
#include "RMA.h"
//Implement the Royal Mathematician's Algorithm in C++.





int main(int argc, char* argv[]) {
    std::list<std::string>finalList= RMA(argc,argv);
    for (auto const &v : finalList){
        std::cout<<v<<"\n";
    }
    }








