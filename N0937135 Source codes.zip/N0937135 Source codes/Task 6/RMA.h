//
// Created by Oliver Reeves on 13/12/2022.
//
#include <iostream>
#include <list>
#include <string>
#include <vector>
#include <fstream>
#ifndef TASK_6_RMA_H
#define TASK_6_RMA_H

#endif //TASK_6_RMA_H


bool myComparison(const std::pair<std::string,std::string> &a,const std::pair<std::string,std::string> &b)
{
    return a.second<b.second;
}
bool myComparisonnumerical(const std::pair<std::string,int> &a,const std::pair<std::string,int> &b)
{
    return a.second<b.second;
}




std::list<std::string> RMA(int argc, char* argv[]) {

    std::fstream readfile(argv[1]);
    std::string line;
    std::pair<std::string,std::string> sep;
    std::list<std::pair<std::string,std::string>> tapeA;


    while (std::getline(readfile, line))
    {

        auto index = line.find(',');
        sep = std::make_pair(
                line.substr(0,index),
                line.substr(index+1)
        );
        tapeA.push_back(sep);
    }

    std::list<std::pair<std::string,std::string>> tapeB;
    tapeB=tapeA;

    tapeA.sort(myComparison);
    tapeB.sort();



    std::list<std::pair<std::string,int>> tapeP;
    std::list<std::pair<std::string,std::string>> tapeC;

    std::string a1=tapeA.begin()->first;
    std::string a2=tapeA.begin()->second;
    std::string b1=tapeB.begin()->first;
    std::string b2=tapeB.begin()->second;
    int sizeA=tapeA.size();
    int sizeB=tapeB.size();
    int N=tapeA.size()+1;
    int positionA=0;
    int positionB=0;

    while(positionA<=sizeA-1){
        a1=std::next(tapeA.begin(),positionA)->first;
        a2=std::next(tapeA.begin(),positionA)->second;
        b1=std::next(tapeB.begin(),positionB)->first;
        b2=std::next(tapeB.begin(),positionB)->second;
        if(a2==b1){
            tapeC.push_back({a1,b2});
            positionA+=1;
            if(positionB<sizeB-1){
                positionB+=1;}}
        else if(a2<b1){
            tapeP.push_back({a1,N-1});
            tapeP.push_back({a2,N});
            positionA+=1;
        }
        else if(a2>b1){
            if(positionB<sizeB-1){
                positionB+=1;}}
    }


    tapeP.sort();




    std::list<std::pair<std::string,int>>tapeF;
    std::string p1;
    int p2;

    int d=2;

    while (d<N){
        tapeA=tapeC;
        tapeB=tapeC;
        tapeC.erase(tapeC.begin(),tapeC.end());
        tapeA.sort(myComparison);
        tapeB.sort();
        int Bsize=tapeB.size();
        int tapePsize=tapeP.size();
        //iterate through tape A
        positionA=0;
        positionB=0;
        int positionP=0;
        int Asize=tapeA.size();
        while(positionA<=Asize-1){
            a1=std::next(tapeA.begin(),positionA)->first;
            a2=std::next(tapeA.begin(),positionA)->second;
            b1=std::next(tapeB.begin(),positionB)->first;
            b2=std::next(tapeB.begin(),positionB)->second;
            p1=std::next(tapeP.begin(),positionP)->first;
            p2=std::next(tapeP.begin(),positionP)->second;

            if(a2==b1){
                tapeC.push_back({a1,b2});
                positionA+=1;
                if(positionB<Bsize-1){
                    positionB+=1;}}
            else if(a2==p1){
                tapeF.push_back({a1,p2-d});

                positionA+=1;
                if(positionP<tapePsize-1){
                    positionP+=1;}
            }
            else if(a2>p1){
                if(positionP<tapePsize-1){
                    positionP+=1;}
                else if (positionB<Bsize-1){
                    positionB+=1;
                }}
            else if(a2>b1){
                if(positionB<Bsize-1){
                    positionB+=1;
                }
            }

        }
        tapeF.sort();
        tapeP.merge(tapeF);
        tapeF.erase(tapeF.begin(),tapeF.end());
        d=2*d;

    }



    tapeP.sort(myComparisonnumerical);
    std::list<std::string> finalresults;
    for (auto const &v : tapeP){
        finalresults.push_back(v.first);
    }
    return finalresults;



}