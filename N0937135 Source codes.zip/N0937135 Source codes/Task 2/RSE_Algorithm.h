//
// Created by Oliver Reeves on 07/12/2022.
//
#include "string"
#include "unordered_map"
#include "list"
#include <iostream>
#include <chrono>
#include <fstream>
#include <utility>
#ifndef TASK_2_RSE_ALGORITHM_H
#define TASK_2_RSE_ALGORITHM_H

#endif //TASK_2_RSE_ALGORITHM_H
using namespace std;
class RSE{
public:
    unordered_map<string, string> mapOfBricks;
    unordered_map<string, string> reversedmapOfBricks;
    std::pair<std::string,std::string> startValues;
    list<string>  royalList;

    void loadData(string a);
    list<string> RoyalAlgorithm(string currentBrick,string nextBrick,int option);


private:



};

void RSE::loadData(std::string a) {
    std::fstream readfile(a);
    std::string line;
    std::getline(readfile,line);
    auto index = line.find(',');
    std::pair<std::string,std::string> sep;

    sep = std::make_pair(
            line.substr(0,index),
            line.substr(index+1)
    );
    mapOfBricks[sep.first]=sep.second;
    startValues={sep.first,sep.second};

    while (std::getline(readfile, line))
    {
        // Line contains string of length > 0 then save it in vector

        //std::string str;
        auto index = line.find(',');


        sep = std::make_pair(
                line.substr(0,index),
                line.substr(index+1)
        );
        mapOfBricks[sep.first]=sep.second;
    }
    //steady_clock::time_point loadFinishTime = steady_clock::now();

    //steady_clock::time_point algoStartTime = steady_clock::now();
    for(auto i:mapOfBricks){
        reversedmapOfBricks[i.second]=i.first;
    }
}

list<string> RSE::RoyalAlgorithm(string currentBrick,string nextBrick,int option) {

    //forward search x x+1-> x+1 x+2->x+2 x+3
    //case 0
    while(1==1){

        if (mapOfBricks.find(nextBrick) != mapOfBricks.end()) {

            royalList.push_back(currentBrick);
            currentBrick = mapOfBricks.find(nextBrick)->first;
            nextBrick = mapOfBricks.find(nextBrick)->second;
            //return RoyalAlgorithm(currentBrick, nextBrick,0);

        } else {
            //push brick that was linked to missing brick
            royalList.push_back(currentBrick);
            royalList.push_back(nextBrick);
            //now we reverse the order
            currentBrick=startValues.first;
            nextBrick=startValues.second;
            break;
            //return RoyalAlgorithm(startValues.first, startValues.second,1);

        }
    }
    //case 1
    while(1==1){
        //backwards x x+1 -> x+5 x

        if (reversedmapOfBricks.find(nextBrick) != reversedmapOfBricks.end()) {
            // cout << "rev linked brick is" << reversedmapOfBricks.find(nextBrick)->first << " "
            //    << reversedmapOfBricks.find(nextBrick)->second << endl;
            if((currentBrick!=startValues.first and currentBrick!=startValues.second)or(currentBrick==startValues.first and nextBrick!=startValues.first and nextBrick!=startValues.second)){
                royalList.push_front(nextBrick);}


            currentBrick = reversedmapOfBricks.find(nextBrick)->first;
            nextBrick = reversedmapOfBricks.find(nextBrick)->second;
            //return RoyalAlgorithm(currentBrick, nextBrick,1);

        } else {
            //push brick that was linked to missing brick
            royalList.push_front(nextBrick);
            return royalList;
        }
    }

}