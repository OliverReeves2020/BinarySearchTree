#include <iostream>
#include <vector>
#include <list>
#include <chrono>
#include <fstream>
#include <unordered_map>
#include <utility>
#include "RSE_Algorithm.h"



using namespace std;

using std::chrono::steady_clock;

using std::chrono::nanoseconds;
using std::chrono::duration_cast;






int main(int argc, char* argv[]) {

    //algorithm is split into load and algorithm function to allow for time pefermonace analysis in the testing program

    RSE royal;
    //loads file path
    royal.loadData(argv[1]);
    //sets starting position with the assumption that the first brick pair in the list is random
    string startA=royal.startValues.first;
    string startB=royal.startValues.second;
    //calls royal algorithm and retruns list to as only output to the console
    list<string> royalList=royal.RoyalAlgorithm(startA,startB,0);

    //task 2 specifaclly only excepts this as an output
    for (auto const &v : royalList)
       std::cout << v<<"\n";



}
