#include <iostream>
#include "../Task 2/RSE_Algorithm.h"
#include "../Task 2 B/RSE_Algorithm_Worst.h"
#include "../Task 6/RMA.h"
#include <chrono>
using namespace std;
using std::chrono::steady_clock;
using std::chrono::nanoseconds;
using std::chrono::duration_cast;


int main(int argc, char* argv[]) {



    RSE royal;

    steady_clock::time_point loadStartTime = steady_clock::now();
    royal.loadData(argv[1]);
    steady_clock::time_point loadFinishTime = steady_clock::now();


    string startA=royal.startValues.first;
    string startB=royal.startValues.second;
    steady_clock::time_point algoStartTime = steady_clock::now();
    list<string> royalList=royal.RoyalAlgorithm(startA,startB,0);
    steady_clock::time_point algoFinishTime = steady_clock::now();
    nanoseconds loadTimeTaken = duration_cast<nanoseconds>(loadFinishTime - loadStartTime);
    nanoseconds algoTimeTaken = duration_cast<nanoseconds>(algoFinishTime - algoStartTime);
    nanoseconds totalTimeTaken = duration_cast<nanoseconds>(loadTimeTaken+algoTimeTaken);

    std::cout<<"best case time to load data: "<<loadTimeTaken.count()<<endl;
    std::cout<<"best case time for algorithm to finish: "<<algoTimeTaken.count()<<endl;
    std::cout<<"best case total time taken: "<<totalTimeTaken.count()<<endl;


    RSEWORST royalworst;
    loadStartTime = steady_clock::now();
    royalworst.loadData(argv[1]);
    loadFinishTime = steady_clock::now();


    startA=royalworst.startValues.first;
    startB=royalworst.startValues.second;
    algoStartTime = steady_clock::now();
    royalworst.RoyalAlgorithm(startA,startB,0);
    algoFinishTime = steady_clock::now();
    loadTimeTaken = duration_cast<nanoseconds>(loadFinishTime - loadStartTime);
    algoTimeTaken = duration_cast<nanoseconds>(algoFinishTime - algoStartTime);
    totalTimeTaken = duration_cast<nanoseconds>(loadTimeTaken+algoTimeTaken);

    std::cout<<"worst case time to load data: "<<loadTimeTaken.count()<<endl;
    std::cout<<"worst case time for algorithm to finish: "<<algoTimeTaken.count()<<endl;
    std::cout<<"worst case total time taken: "<<totalTimeTaken.count()<<endl;


    steady_clock::time_point RMAStartTime = steady_clock::now();
    std::list<std::string>finalList= RMA(argc,argv);
    steady_clock::time_point RMAFinishTime = steady_clock::now();
    totalTimeTaken = duration_cast<nanoseconds>(RMAFinishTime - RMAStartTime);
    std::cout<<"RMA total time in nanoseconds:"<<totalTimeTaken.count();

}
